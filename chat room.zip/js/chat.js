/*
HFS文件聊天
这只是JavaScript/JQuery代码
没有PHP, MySQL, node.js和另一个服务器端。

现在你不需要在任何地方注册，
不需要创建任何通道和房间，
无需连接Internet(此聊天可以在本地网络中工作)，
*/


var message_number = 0; //1-st message number

//从某个功能转移号码
function number_in_script(new_message_number) {
	message_number = new_message_number;
	if (document.getElementById("last_message") === null) {} else {
		document.getElementById("last_message").innerHTML = new_message_number;
	}
}


//修改文本链接->到HTML链接。
function linkify(inputText) {
	var replacedText, replacePattern1, replacePattern2, replacePattern3;

	//url以http://， https://，或ftp://开头
	replacePattern1 = /(\b(http?|https?|ftp?|ftps):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gim;
	replacedText = inputText.replace(replacePattern1, '<a href="$1" target="_blank">$1</a>');

	//以“www”开头的url。(前面没有//，否则它会重新链接上面所做的)。
	replacePattern2 = /(^|[^\/])(www\.[\S]+(\b|$))/gim;
	replacedText = replacedText.replace(replacePattern2, '$1<a href="http://$2" target="_blank">$2</a>');

	//将电子邮件地址更改为mailto::链接。
	replacePattern3 = /(([a-zA-Z0-9\-\_\.])+@[a-zA-Z\_]+?(\.[a-zA-Z]{2,6})+)/gim;
	replacedText = replacedText.replace(replacePattern3, '<a href="mailto:$1">$1</a>');

	return replacedText;
}

function del(obj) {
	document.cookie = "username=; expires=Thu, 01 Jan 1970 00:00:00 GMT";
}

function setCookie(cname, cvalue, exdays) {
	var d = new Date();
	d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
	var expires = "expires=" + d.toGMTString();
	document.cookie = cname + "=" + cvalue + "; " + expires;
}

function getCookie(cname) {
	var name = cname + "=";
	var ca = document.cookie.split(';');
	for (var i = 0; i < ca.length; i++) {
		var c = ca[i].trim();
		if (c.indexOf(name) == 0) {
			return c.substring(name.length, c.length);
		}
	}
	return "";
}

function save_username() {
	var user = getCookie("username");
	if (user != "") {} else {
		user = prompt("请输入你的名字", "Guest");
		if (user != "" && user != null) {
			setCookie("username", user, 30);
		}
	}
	if (!user || user === ' ') {
		user = "Guest";
	}
	user = user.replace(/(<([^>]+)>)/ig, "");
	if (user != null) {
		document.getElementById("username").innerHTML =
			user + ': ';
		$("#name-area").html("您的名称:<span>" + user + "</span>");
	}
}

//得到第n条消息，其中n是一个数字。
function get_file(number) {
	if (number === 0) {
		var url = './up/message.txt'; //第一个消息
	} else {
		var url = './up/message (' + number + ').txt'; // n-th message
	}

	xhr = new XMLHttpRequest();
	xhr.open("GET", url);
	xhr.setRequestHeader('Cache-Control', 'no-cache'); //从服务器下载消息作为文件，不缓存这个。
	xhr.send(); //发送XHR查询下载文件。
	xhr.onerror = function (number) {
		console.log("error" + xhr.status);
	}
	xhr.onload = function () { //文件加载
		if ( //检查状态和内容
			this.status === 404 //如果状态为404(未找到代码)
			||
			this.responseText.indexOf('<h1>Not found</h1>') !== -1 //或者是否存在 "<h1>Not found</h1>" 代码内部。
		) {} //不要什么都不做
		else {
			//消息收到。
			var nickname = this.responseText.split(': ')[0]; //插入的昵称
			var message = this.responseText.split(': ')[1]; //插入消息
			//更换链接
			var message = linkify(message); //改变链接
			var code = '<div id="namemessagediv">' + '<span>' + nickname + '</span>' + '<div id="messagediv">' + message + '</div>' + '</div>'; //给消息添加标签
			document.getElementById('chat-area').innerHTML += code; //显示这个
			// //添加声音并播放。
			$('body').append($('<audio id="chatAudio"><source src="notify.ogg" type="audio/ogg"><source src="notify.mp3" type="audio/mpeg"><source src="notify.wav" type="audio/wav"></audio>'));
			$('#chatAudio')[0].play();
			$("#chat-area").scrollTop($("#chat-area")[0].scrollHeight);
			//增加数量
			number_in_script(number + 1);
			//请尝试下载下一条消息。
			get_file(number + 1);
		}
	}
	xhr.upload.onerror = function (number) {
		console.log("error" + xhr.status);
	}
}

//将此消息作为文件发送到HFS服务器上的隐藏文件夹。
function save_message_as_file() {
	var nickname = document.getElementById('username').innerHTML;
	var message = document.getElementById('sendie').value;
	console.log('message', message);

	var formData = new FormData();
	var blob = new Blob([nickname + message], {
		type: 'plain/text'
	});
	formData.append('file', blob, 'message.txt');

	var request = new XMLHttpRequest();
	request.open('POST', './up');
	request.send(formData);
}

function add() {
	var now = new Date();
	var div = document.getElementById('scrolldIV');
	div.innerHTML = div.innerHTML + 'time_' + now.getTime() + '<br />';
	div.scrollTop = div.scrollHeight;
}
//textarea functions...
$(function () {
	// 查看文本框中的按键
	$("#sendie").keydown(function (event) {
		var key = event.which;
		//包括return在内的所有键。
		if (key >= 33) {
			var maxLength = $(this).attr("maxlength");
			var length = this.value.length;
			// 如果长度超过上限，就不要添加新内容
			if (length >= maxLength) {
				event.preventDefault();
			}
		}
	});

	// 查看文本区以释放按键
	$('#sendie').keyup(function (e) {
		if (e.keyCode == 13) {
			var text = $(this).val();
			var maxLength = $(this).attr("maxlength");
			var length = text.length;
			// send 
			if (length <= maxLength + 1) {
				save_message_as_file(); //将消息保存为文件并上传到HFS
				$(this).val("");
			} else {
				$(this).val(text.substring(0, maxLength));
			}
		}
	});
});