window.AudioContext = window.AudioContext || window.webkitAudioContext || window.mozAudioContext || window
    .msAudioContext;
try {
    var context = new window.AudioContext();;
    var source = null;
    var audioBuffer = null;

    function stopSound() {
        if (source) {
            source.stop(0); //停止
        }
    }

    function playSound() {
        source = context.createBufferSource();
        source.buffer = audioBuffer;
        source.loop = true; //循环
        source.connect(context.destination);
        source.start(0); //播放
    }

    function initSound(arrayBuffer) {
        context.decodeAudioData(arrayBuffer, function (buffer) { //解码成功时的回调函数
            audioBuffer = buffer;
            playSound();
        }, function (e) { //解码出错时的回调函数
            console.log('Error decoding file', e);
        });
    }

    function loadAudioFile(url) {
        var xhr = new XMLHttpRequest(); //通过XHR下载音频文件
        xhr.open('GET', url, true);
        xhr.responseType = 'arraybuffer';
        xhr.onload = function (e) { //下载完成
            initSound(this.response);
        };
        xhr.send();
    }
    loadAudioFile('music/bg.m4a');
    $("#stop").click(function () {
        stopSound();
    });
} catch (e) {
    console.log('!您的浏览器不支持AudioContext');
}
// 清空文本框
function ClearTextArea() {
    document.getElementById("sendie").value = "";
}
// 设置界面
function toggleset() {
    $("#setting").toggle();
}

// 音乐控制
function musicstop() {
    $("#musict").toggle();
    $("#musics").toggle();
    stopSound()
}

function musicgo() {
    $("#musics").toggle();
    $("#musict").toggle();
    playSound()
}

// 缩放模式
// function sfk() {
//     $("#sfg").toggle();
//     $("#sfk").toggle();
//     var obj = document.getElementById("left")
//     obj.style.width = "25%";
//     var obj = document.getElementById("right")
//     obj.style.width = "75%";
//     var obj = document.getElementById("musict")
//     obj.style.bottom = "";
//     var obj = document.getElementById("musics")
//     obj.style.bottom = "";
// }

// function sfg() {
//     $("#sfk").toggle();
//     $("#sfg").toggle();
//     var obj = document.getElementById("left")
//     obj.style.width = "60px";
//     var obj = document.getElementById("right")
//     obj.style.width = "860px";
//     var obj = document.getElementById("musict")
//     obj.style.bottom = "60px";
//     var obj = document.getElementById("musics")
//     obj.style.bottom = "60px";
// }

// 暗夜模式
function yjk() {
    $("#yjk").toggle();
    $("#yjg").toggle();
    var obj = document.getElementById("left")
    obj.style.background = "rgba(0, 0, 0, 0.3)";
    var obj = document.getElementById("right")
    obj.style.background = "rgba(0, 0, 0, 0.3)";
    var obj = document.getElementById("chat-area")
    obj.style.background = "rgba(0, 0, 0, 0.1)";
    var obj = document.getElementById("sendie")
    obj.style.color = "#eee";
}

function yjg() {
    $("#yjg").toggle();
    $("#yjk").toggle();
    var obj = document.getElementById("left")
    obj.style.background = "rgba(255, 255, 255, 0.3)";
    var obj = document.getElementById("right")
    obj.style.background = "rgba(255, 255, 255, 0.3)";
    var obj = document.getElementById("chat-area")
    obj.style.background = "rgba(255, 255, 255, 0.6)";
    var obj = document.getElementById("sendie")
    obj.style.color = "#000";
}
// 跳到最新消息
function toolbartop() {
    $("#chat-area").scrollTop($("#chat-area")[0].scrollHeight);
}